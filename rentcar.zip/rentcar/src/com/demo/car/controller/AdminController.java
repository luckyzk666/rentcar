package com.demo.car.controller;

import com.demo.car.pojo.Car;
import com.demo.car.pojo.Orders;
import com.demo.car.pojo.Users;
import com.demo.car.pojo.vo.FindVo;
import com.demo.car.service.AdminService;
import com.demo.car.service.CarService;
import com.demo.car.service.OrdersService;
import com.demo.car.service.UserService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

/**
 * @author 张坤
 * @version 1.0
 * @title: AdminController
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/21   下午 10:21
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private OrdersService orderService;

    @Autowired
    private CarService carService;

    @Autowired
    private UserService userService;

    //登录
    @RequestMapping("/login")
    public String adminLogin(String aName, String aPass, HttpSession session) {
        Map<String, Object> map = adminService.login(aName, aPass);
        if ("ok".equals(map.get("str"))) {
            session.setAttribute("admin", map.get("admin"));
//            return "redirect:/admin/getAllOrder.action";
            return "admin/main";
        }

        session.setAttribute("err", map.get("str"));
        return "admin/login";
    }

    //查看所有订单
    @RequestMapping("/getAllOrder")
    public String getAllOrder(
            @RequestParam(defaultValue = "1")
                    Integer page,
            @RequestParam(defaultValue = "3")
                    Integer pageSize,
            HttpSession session) {
        PageInfo pageInfo = orderService.getAll(page, pageSize);
        session.setAttribute("OrderInfo", pageInfo);
        //  return "admin/AdminMain";
        return "admin/AdminMain";
    }

    //多条件查所有订单
//    public String ;getAllCondition
    @RequestMapping("/getAllCondition")
    public String getAllCondition(
            FindVo vo,
       /*     @RequestParam(defaultValue = "1")
                    Integer page,
            @RequestParam(defaultValue = "3")
                    Integer pageSize,*/
            HttpSession session) {
        List<Orders> orders = orderService.getAllCondition(vo);
        session.setAttribute("AllOrderInfo", orders);
        return "admin/AdminAllOrders";

    }

    //查看所有车辆
    @RequestMapping("/getAllCar")
    public String getAllCar(
            @RequestParam(defaultValue = "1")
                    Integer page,
            @RequestParam(defaultValue = "3")
                    Integer pageSize,
            HttpSession session) {
        PageInfo info = carService.getAllCar(page, pageSize);
        session.setAttribute("carInfo", info);
        return "admin/AdminCar";
    }

    //根据Cid查一个汽车
    @RequestMapping("/getByCid")
    public String getByCid(Integer cid, HttpSession session) {
        session.setAttribute("car", carService.getByCid(cid));
        return "admin/updatecar";
    }

    //增加车辆
    @RequestMapping("/addCar")
    public String addCar(Car car, HttpSession session) {
        List<Car> carList = carService.getAllCarList();
        for (Car c : carList) {
            if (c.getcPlate().equals(car.getcPlate())) {
                session.setAttribute("addCarErr", "添加失败，汽车车牌重复");
                return "redirect:/admin/addCarErr.jsp";
            }
        }
        carService.addNewCar(car);

        return "redirect:/admin/getAllCar.action";
    }


    //修改车辆信息
    @RequestMapping("/updateCar")
    public String updateCar(Car car, HttpSession session) {
        List<Car> carList = carService.getAllCarList();
        int i = 0;

        Car car1 = carService.getByCid(car.getcId());
        if (!car1.getcPlate().equals(car.getcPlate())) {

            for (Car c : carList) {
                if (c.getcPlate().equals(car.getcPlate())) {
                    session.setAttribute("addCarErr", "添加失败，汽车车牌重复");
                    return "redirect:/admin/addCarErr.jsp";
                } else {
                    carService.updateCar(car);
                    return "redirect:/admin/getAllCar.action";

                }

            }

        } carService.updateCar(car);
         return "redirect:/admin/getAllCar.action";
    }
    /*
            for (Car c:carList) {
                if (c.getcPlate().equals(car.getcPlate())){
                    i++;
                    if (i==2){
                        session.setAttribute("addCarErr","添加失败，汽车车牌重复");
                        return "redirect:/admin/addCarErr.jsp";
                    }

                }
            }
    */
    //删除车辆
    @RequestMapping("/deleteCar")
    public String deleteCar(Integer cId) {
        carService.deleteCar(cId);
        return "redirect:/admin/getAllCar.action";
    }

    /**
     * 用户
     */

    //查全部用户
    @RequestMapping("/getAllUser")
    public String getAllUser(
            @RequestParam(defaultValue = "1")
                    Integer page,
            @RequestParam(defaultValue = "3")
                    Integer pageSize,
            HttpSession session) {
        PageInfo info = userService.getAllUser(page, pageSize);
        session.setAttribute("userInfo", info);
        return "admin/alluser";
    }

    //根据Uid查询一个用户
    @RequestMapping("/getByUid")
    public String getByUid(Integer uId, HttpSession session) {
        session.setAttribute("users", userService.getByUid(uId));
        return "admin/updateUser";
    }

    //add用户
    @RequestMapping("/addNewUser")
    public String addNewUser(Users users) {
        userService.addNewUser(users);
        return "redirect:/admin/getAllUser.action";
    }

    //delete
    @RequestMapping("/deleteUser")
    public String deleteUser(Integer uId) {
            userService.deleteUser(uId);
        return "redirect:/admin/getAllUser.action";
    }

    //update用户
    @RequestMapping("/updateUser")
    public String updateUser(Users user) {
        userService.updateUser(user);
        return "redirect:/admin/getAllUser.action";
    }


}
