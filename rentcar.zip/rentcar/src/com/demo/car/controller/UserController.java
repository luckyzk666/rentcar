package com.demo.car.controller;

import com.demo.car.pojo.Orders;
import com.demo.car.service.CarService;
import com.demo.car.service.OrdersService;
import com.demo.car.service.UserService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/user")
public class UserController {


    @Autowired
    private UserService userService;

    @Autowired
    private OrdersService ordersService;

    @Autowired
    private CarService carService;

    //login   user
    @RequestMapping("login")
    public String login(String uName, String uPass, HttpSession session) {
        Map<String, Object> map = userService.login(uName, uPass);
        if ("ok".equals(map.get("str"))) {
            session.setAttribute("user", map.get("user"));
//            return "redirect:/user/getAllCar.action";
            return "main";
        }

        session.setAttribute("userErr",map.get("str"));
        return "index";

    }
    //根据Cid查一个汽车
    @RequestMapping("/getByCid")
    public String getByCid(Integer cid,HttpSession session){
        session.setAttribute("car",carService.getByCid(cid));
        return "addNewOrder";
    }
    //查看所有车辆
    @RequestMapping("/getAllCar")
    public String getAllCar(
            @RequestParam(defaultValue = "1")
                    Integer page,
            @RequestParam(defaultValue = "3")
                    Integer pageSize,
            HttpSession session){
        PageInfo info=carService.getAllCar(page,pageSize);
        session.setAttribute("carInfo",info);
        return "AllCar";
    }


    //根据Uid查用户所有订单记录
    @RequestMapping("/getAllOrderByUid")
    public String getAllOrderByUid(Integer uId,
           @RequestParam(defaultValue = "1")
               Integer page,
           @RequestParam(defaultValue = "3")
                       Integer pageSize,
           HttpSession session){
        List<Orders> info=ordersService.getAllByUid(uId);
        session.setAttribute("orderInfo",info);
        return "AllOrderByUid";
    }


    //下单租车

    @RequestMapping("/rentCar")
    public String rentCar(Integer cid,Integer uId,String startDate,String endDate,Integer totalAmount,HttpSession session) throws ParseException {
        SimpleDateFormat sf =new SimpleDateFormat("yyyy-MM-dd");
        Date begin=sf.parse(startDate);
        Date end=sf.parse(endDate);

        Orders orders=new Orders();
//        orders.setUserId(((Users)session.getAttribute("user")).getuId());
        orders.setUserId(uId);
        orders.setCarId(cid);
        orders.setStartTime(begin);
        orders.setEndTime(end);

    //    System.out.println("总价格："+totalAmount);
        BigDecimal number = new BigDecimal(0);
        int value=totalAmount;
        number=BigDecimal.valueOf((int)value);
         orders.setCountPrice(number);
        Integer num=ordersService.addNewOrder(orders);

        if(num>0){
            session.setAttribute("rentOk","租车成功");
            return "redirect:/user/getAllOrderByUid.action?uId="+uId;
        }

        //不成功
        return "";
    }

    //根据Oid查单个订单
    @RequestMapping("/FindByOid")
    public String FindByOid(Integer oId,HttpSession session){
       Orders orders= ordersService.FindByOid(oId);
        session.setAttribute("order",orders);
        return "huanche";
    }
    //根据Oid查单个订单续借
    @RequestMapping("/FindByOidxj")
    public String FindByOidxj(Integer oId,HttpSession session){
       Orders orders= ordersService.FindByOid(oId);
        session.setAttribute("order",orders);
        return"xujie";
    }



        //还车
    @RequestMapping("/haunChe")
    public String huanChe(Orders ord,String startDate,String endDate,String realDate)throws Exception{
        SimpleDateFormat sf =new SimpleDateFormat("yyyy-MM-dd");
        ord.setStartTime(sf.parse(startDate));
        ord.setEndTime(sf.parse(endDate));
        ord.setRealTime(sf.parse(realDate));
        ordersService.updateCarHuan(ord);

        return "redirect:/user/getAllOrderByUid.action?uId="+ord.getUserId();

    }


    //续借
    @RequestMapping("/xuJie")
    public String xuJie(Orders ord,String startDate,String endDate,HttpSession session) throws ParseException {
        SimpleDateFormat sf =new SimpleDateFormat("yyyy-MM-dd");

//        Orders orders=new Orders();
//        orders.setoId(ord.getoId());
       ord.setStartTime(sf.parse(startDate));
       ord.setEndTime(sf.parse(endDate));

        int num=ordersService.updateTwo(ord);
        if(num>0){
            session.setAttribute("successful","续借成功");
            return "redirect:/user/getAllOrderByUid.action?uId="+ord.getUserId();
        }

        session.setAttribute("errr","续借失败");
        return "redirect:/user/getAllOrderByUid.action?uId="+ord.getUserId();

    }







}
