package com.demo.car.service;


import com.demo.car.pojo.Orders;
import com.demo.car.pojo.vo.FindVo;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * @author 张坤
 * @version 1.0
 * @title: OrderService
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/21   下午 10:44
 */
public interface OrdersService {

    //借车
    Integer addNewOrder(Orders order);

    //还车
    Integer updateCarHuan(Orders order);

    //续借
    Integer updateTwo(Orders order);

    //查用户名下的订单
    List<Orders> getAllByUid(Integer uid);

    //查询所有订单
    PageInfo getAll(Integer page,Integer pageSize);

    //多条件查询
    List<Orders> getAllCondition(FindVo vo);

     //根据Oid查单个订单
    Orders FindByOid(Integer oId);




}
