package com.demo.car.service;

import java.util.Map;

/**
 * @author 张坤
 * @version 1.0
 * @title: AdminService
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/21   下午 10:14
 */
public interface AdminService {

    Map<String,Object> login(String aName,String aPass);
}
