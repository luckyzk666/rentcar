package com.demo.car.service.impl;

import com.demo.car.mapper.CarMapper;
import com.demo.car.pojo.Car;
import com.demo.car.pojo.CarExample;
import com.demo.car.service.CarService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 刘密军
 * @version 1.0
 * @title: CarServiceImpl
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/21   下午 10:33
 */
@Service
public class CarServiceImpl implements CarService {

    @Autowired
    private CarMapper carMapper;

    @Override
    public Integer addNewCar(Car car) {
        return carMapper.insert(car);
    }

    @Override
    public Integer deleteCar(Integer cId) {
        return carMapper.deleteByPrimaryKey(cId);
    }

    @Override
    public Integer updateCar(Car car) {
        return carMapper.updateByPrimaryKey(car);
    }

    @Override
    public PageInfo getAllCar(Integer page, Integer pageSize) {
        CarExample example =new CarExample();
        PageHelper.startPage(page,pageSize);
        List<Car> carList=carMapper.selectByExample(example);
        PageInfo<Car> info= new PageInfo<>(carList);
        return info;
    }

    //根据Cid查一个汽车
    @Override
    public Car getByCid(Integer cid) {
        return carMapper.selectByPrimaryKey(cid);
    }
    //查询全部汽车
    @Override
    public List<Car> getAllCarList() {
        CarExample example =new CarExample();
        List<Car> carList=carMapper.selectByExample(example);
        return carList;
    }
}
