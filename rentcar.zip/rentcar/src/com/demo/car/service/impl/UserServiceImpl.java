package com.demo.car.service.impl;

import com.demo.car.mapper.UsersMapper;
import com.demo.car.pojo.Users;
import com.demo.car.pojo.UsersExample;
import com.demo.car.service.UserService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 刘密军
 * @version 1.0
 * @title: UserServiceImpl
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/21   下午 10:41
 */
@Service
public class UserServiceImpl implements UserService {


    @Autowired
    private UsersMapper userMapper;
    @Override
    public Map<String, Object> login(String uName, String uPass) {
        Map<String,Object> map=new HashMap<>();
        UsersExample example=new UsersExample();
        example.createCriteria().andUNameEqualTo(uName);

        List<Users> users=userMapper.selectByExample(example);
        if(users.size()!=0){
            Users user=users.get(0);
            if(uPass.equals(user.getuPass())){
                map.put("user",user);
                map.put("str","ok");
            }else {
                map.put("str","用户名或密码不正确");
            }
        }else {
            map.put("str","用户名或密码不正确");
        }
        return map;
    }

    @Override
    public Integer addNewUser(Users user) {
        return userMapper.insert(user);
    }

    @Override
    public Integer deleteUser(Integer uId) {
        return userMapper.deleteByPrimaryKey(uId);
    }

    @Override
    public Integer updateUser(Users user) {
        return userMapper.updateByPrimaryKey(user);
    }

    @Override
    public PageInfo getAllUser(Integer page, Integer pageSize) {
        UsersExample example=new UsersExample();
        PageHelper.startPage(page,pageSize);
        List<Users> userList=userMapper.selectByExample(example);
        PageInfo<Users> info=new PageInfo<>(userList);
        return info;
    }
    //根据cid查询一个用户
    @Override
    public Users getByUid(Integer uId) {
        return userMapper.selectByPrimaryKey(uId);
    }
}
