package com.demo.car.service.impl;

import com.demo.car.mapper.AdminMapper;
import com.demo.car.pojo.Admin;
import com.demo.car.pojo.AdminExample;
import com.demo.car.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 刘密军
 * @version 1.0
 * @title: AdminServiceImpl
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/21   下午 10:14
 */
@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminMapper adminMapper;

    @Override
    public Map<String, Object> login(String aName, String aPass) {
        Map<String,Object> map=new HashMap<>();
        AdminExample example=new AdminExample();
        example.createCriteria().andANameEqualTo(aName);

        List<Admin> admins=adminMapper.selectByExample(example);
        if(admins.size()!=0){
            Admin admin=admins.get(0);
            if(aPass.equals(admin.getaPass())){
                map.put("admin",admin);
                map.put("str","ok");
            }else {
                map.put("str","用户名或密码不正确");
            }
        }else {
            map.put("str","用户名或密码不正确");
        }
        return map;

    }
}
