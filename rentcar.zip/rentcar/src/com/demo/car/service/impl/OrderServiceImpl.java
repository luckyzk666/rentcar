package com.demo.car.service.impl;

import com.demo.car.mapper.CarMapper;
import com.demo.car.mapper.OrdersMapper;
import com.demo.car.mapper.UsersMapper;
import com.demo.car.pojo.Car;
import com.demo.car.pojo.Orders;
import com.demo.car.pojo.OrdersExample;
import com.demo.car.pojo.Users;
import com.demo.car.pojo.vo.FindVo;
import com.demo.car.service.OrdersService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 刘密军
 * @version 1.0
 * @title: OrdersServiceImpl
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/21   下午 10:49
 */
@Service
public class OrderServiceImpl implements OrdersService {

    @Autowired
    private OrdersMapper ordersMapper;

    @Autowired
    private UsersMapper userMapper;

    @Autowired
    private CarMapper carMapper;

    //租车生成新订单
    @Override
    public Integer addNewOrder(Orders orders) {
        //租车后，查出原车辆信息并把汽车数量-1
        Car car=carMapper.selectByPrimaryKey(orders.getCarId());
        car.setcNumber(car.getcNumber()-1);
        carMapper.updateByPrimaryKey(car);

        return ordersMapper.insert(orders);
    }

    //还车
    @Override
    public Integer updateCarHuan(Orders orders) {
        //还车后，查出原车辆信息并把汽车数量+1
        Car car=carMapper.selectByPrimaryKey(orders.getCarId());
        car.setcNumber(car.getcNumber()+1);
        carMapper.updateByPrimaryKey(car);

        return ordersMapper.updateByPrimaryKey(orders);
    }

    //续借
    @Override
    public Integer updateTwo(Orders orders) {

        return ordersMapper.updateByPrimaryKey(orders);
    }

    //根据UID查所有订单记录
    @Override
    public List<Orders> getAllByUid(Integer uid) {
        OrdersExample example = new OrdersExample();
        example.createCriteria().andUserIdEqualTo(uid);
        //  PageHelper.startPage(page,pageSize);
        List<Orders> OrdersList = ordersMapper.selectByExample(example);
     /*   System.out.println("sss"+list);
        PageInfo<Orders> pageInfo=new PageInfo<>(list);*/
        //封装用户和车辆的信息
        for (Orders o : OrdersList) {
            Car car = carMapper.selectByPrimaryKey(o.getCarId());
            o.setCar(car);

            Users user = userMapper.selectByPrimaryKey(o.getUserId());
            o.setUser(user);
        }
        return OrdersList;
    }

    //查询全部
    @Override
    public PageInfo getAll(Integer page, Integer pageSize) {
        OrdersExample example = new OrdersExample();
        PageHelper.startPage(page, pageSize);
        List<Orders> OrdersList = ordersMapper.selectByExample(example);
        //封装用户和车辆的信息
        for (Orders o : OrdersList) {
            Car car = carMapper.selectByPrimaryKey(o.getCarId());
            o.setCar(car);

            Users user = userMapper.selectByPrimaryKey(o.getUserId());
            o.setUser(user);
        }

        PageInfo<Orders> pageInfo = new PageInfo<>(OrdersList);
        return pageInfo;
    }

    //多条件查询
    @Override
    public List<Orders> getAllCondition(FindVo vo) {
        // PageHelper.startPage(page,pageSize);
        List<Orders> OrdersList = ordersMapper.selectConditionSplitPage(vo);

        //   PageInfo<Orders> pageInfo=new PageInfo<>(OrdersList);

        return OrdersList;
    }

    //根据Oid查单个订单
    @Override
    public Orders FindByOid(Integer oId) {
        Orders orders = ordersMapper.selectByPrimaryKey(oId);

        Car car = carMapper.selectByPrimaryKey(orders.getCarId());
        orders.setCar(car);

        Users user = userMapper.selectByPrimaryKey(orders.getUserId());
        orders.setUser(user);

        return orders;
    }
}
