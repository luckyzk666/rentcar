package com.demo.car.service;

import com.demo.car.pojo.Car;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * @author 张坤
 * @version 1.0
 * @title: CarService
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/21   下午 10:30
 */
public interface CarService {

    //管理员
    Integer addNewCar(Car car);

    Integer deleteCar(Integer cId);

    Integer updateCar(Car car);

   PageInfo getAllCar(Integer page,Integer pageSize);

    //根据Cid查一个汽车
   Car  getByCid(Integer cid);
   //查询全部汽车
   List<Car>getAllCarList();




}
