package com.demo.car.service;

import com.demo.car.pojo.Users;
import com.github.pagehelper.PageInfo;

import java.util.Map;

/**
 * @author 张坤
 * @version 1.0
 * @title: UserService
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/21   下午 10:40
 */
public interface UserService {

    Map<String,Object> login(String uName,String uPass);

    Integer addNewUser(Users user);

    Integer deleteUser(Integer uId);

    Integer updateUser(Users user);

    PageInfo getAllUser(Integer page,Integer pageSize);
    //根据cid查询一个用户
    Users getByUid(Integer uId);

}
