package com.demo.car.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class Orders {
    private Integer oId;

    private Integer carId;

    private Integer userId;

    //用户
    private Users user;

    //车辆对象
    private Car car;

    private Date startTime;

    private Date endTime;

    private Date realTime;

    private BigDecimal countPrice;

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Integer getoId() {
        return oId;
    }

    public void setoId(Integer oId) {
        this.oId = oId;
    }

    public Integer getCarId() {
        return carId;
    }

    public void setCarId(Integer carId) {
        this.carId = carId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getRealTime() {
        return realTime;
    }

    public void setRealTime(Date realTime) {
        this.realTime = realTime;
    }

    public BigDecimal getCountPrice() {
        return countPrice;
    }

    public void setCountPrice(BigDecimal countPrice) {
        this.countPrice = countPrice;
    }


    @Override
    public String toString() {
        return "Orders{" +
                "oId=" + oId +
                ", carId=" + carId +
                ", userId=" + userId +
                ", user=" + user +
                ", car=" + car +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", realTime=" + realTime +
                ", countPrice=" + countPrice +
                '}';
    }
}