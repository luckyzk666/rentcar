package com.demo.car.pojo.vo;

/**
 * @author 刘密军
 * @version 1.0
 * @title: FindVo
 * @projectName CarRental_demo
 * @description:
 * @date 2019/12/23   下午 8:47
 */
public class FindVo {
    private String cName;
    private String uName;

    public FindVo(String cName, String uName) {
        this.cName = cName;
        this.uName = uName;
    }

    public FindVo() {
    }

    public FindVo(String cName) {
        this.cName = cName;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

}
