package com.demo.car.pojo;

public class Car {
    private Integer cId;

    private String cName;

    private Double cPrice;

    private Integer cNumber;

    private String cColor;

    private String cImg;

    private String cPlate;

    private String cDeposit;

    public Integer getcId() {
        return cId;
    }

    public void setcId(Integer cId) {
        this.cId = cId;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName == null ? null : cName.trim();
    }

    public Double getcPrice() {
        return cPrice;
    }

    public void setcPrice(Double cPrice) {
        this.cPrice = cPrice;
    }

    public Integer getcNumber() {
        return cNumber;
    }

    public void setcNumber(Integer cNumber) {
        this.cNumber = cNumber;
    }

    public String getcColor() {
        return cColor;
    }

    public void setcColor(String cColor) {
        this.cColor = cColor == null ? null : cColor.trim();
    }

    public String getcImg() {
        return cImg;
    }

    public void setcImg(String cImg) {
        this.cImg = cImg == null ? null : cImg.trim();
    }

    public String getcPlate() {
        return cPlate;
    }

    public void setcPlate(String cPlate) {
        this.cPlate = cPlate == null ? null : cPlate.trim();
    }

    public String getcDeposit() {
        return cDeposit;
    }

    public void setcDeposit(String cDeposit) {
        this.cDeposit = cDeposit == null ? null : cDeposit.trim();
    }
}